#!/bin/bash

touch file{5..8}
